<?php

/*-----------------------------------------------------------------------------------*/
/*	Columns Config
/*-----------------------------------------------------------------------------------*/


$yt_shortcodes['columns'] = array(
	'params' => array(),
	'shortcode' => ' {{child_shortcode}} ', // as there is no wrapper shortcode
	'popup_title' => __('Insert Columns Shortcode', 'yeahthemes'),
	'no_preview' => true,
	
	// child shortcode is clonable & sortable
	'child_shortcode' => array(
		'params' => array(
			'column' => array(
				'type' => 'select',
				'label' => __('Column Type', 'yeahthemes'),
				'desc' => __('Select the type, ie width of the column.', 'yeahthemes'),
				'options' => array(
				
					'one_half_first' 		=> __('1/2 First','yeahthemes'),
					'one_half' 				=> __('1/2','yeahthemes'),
					
					'one_third_first'		=> __('1/3 First','yeahthemes'),
					'one_third' 			=> __('1/3','yeahthemes'),
					'two_third_first' 		=> __('2/3 First','yeahthemes'),
					'two_third' 			=> __('2/3','yeahthemes'),
					
					'one_fourth_first'		=> __('1/4 First','yeahthemes'),
					'one_fourth' 			=> __('1/4','yeahthemes'),
					'three_fourth_first' 	=> __('3/4 First','yeahthemes'),
					'three_fourth' 			=> __('3/4','yeahthemes'),
					
					
					'one_fifth_first' 		=> __('1/5 First','yeahthemes'),
					'one_fifth' 			=> __('1/5','yeahthemes'),
					'two_fifth_first' 		=> __('2/5 First','yeahthemes'),
					'two_fifth' 			=> __('2/5','yeahthemes'),
					'three_fifth_first' 	=> __('3/5 First','yeahthemes'),
					'three_fifth' 			=> __('3/5','yeahthemes'),
					'four_fifth_first' 		=> __('4/5 First','yeahthemes'),
					'four_fifth' 			=> __('4/5','yeahthemes'),
					
					'one_sixth_first' 		=> __('1/6 First','yeahthemes'),
					'one_sixth' 			=> __('1/6','yeahthemes'),
					'five_sixth_first' 		=> __('5/6 First','yeahthemes'),
					'five_sixth' 			=> __('5/6','yeahthemes'),
				)
			),
			'content' => array(
				'std' => '',
				'type' => 'textarea',
				'label' => __('Column Content', 'yeahthemes'),
				'desc' => __('Add the column content.', 'yeahthemes'),
			)
		),
		'shortcode' => '[{{column}}]{{content}}[/{{column}}]',
		'clone_button' => __('Add Column', 'yeahthemes')
	)
);


/*-----------------------------------------------------------------------------------*/
/*	Button Config
/*-----------------------------------------------------------------------------------*/
$yt_shortcodes['button'] = array(
	'no_preview' => true,
	'params' => array(
		'content' => array(
			'std' => 'Button Text',
			'type' => 'text',
			'label' => __('Button\'s Text', 'yeahthemes'),
			'desc' => __('Add the button\'s text', 'yeahthemes'),
		),
		'icon' => array(
			'type' => 'select',
			'label' => __('Icon Font', 'yeahthemes'),
			'desc' => __('Select an icon', 'yeahthemes'),
			'options' => array()
		),
		'iconpos' => array(
			'type' => 'select',
			'label' => __('Position of icon', 'yeahthemes'),
			'desc' => '',
			'options' => array(
				'before' => __('Before Button text', 'yeahthemes'),
				'after' => __('After Button text', 'yeahthemes')
			
			)
		),
		
		'url' => array(
			'std' => '#',
			'type' => 'text',
			'label' => __('Button External URL', 'yeahthemes'),
			'desc' => __('Add the button\'s url eg http://example.com', 'yeahthemes')
		),
		'postid' => array(
			'type' => 'select',
			'label' => __('Internal Pages/posts', 'yeahthemes'),
			'desc' => __('You can alse link to internal pages/posts', 'yeahthemes'),
			'options' =>  array(),
		),
		'style' => array(
			'type' => 'select',
			'label' => __('Button Style', 'yeahthemes'),
			'desc' => __('Select the button\'s style, ie the button\'s colour', 'yeahthemes'),
			'options' => array(
				'standard' => __('Standard','yeahthemes'),
				'primary' => __('Primary color','yeahthemes'),
				'secondary' => __('Secondary color','yeahthemes'),
				'aqua' => __('Aqua','yeahthemes'),
				'blue' => __('Blue','yeahthemes'),
				'dark' => __('Dark','yeahthemes'),
				'green' => __('Green','yeahthemes'),
				'grey' => __('Grey','yeahthemes'),
				'lime' => __('Lime Green','yeahthemes'),
				'orange' => __('Orange','yeahthemes'),
				'pink' => __('Pink','yeahthemes'),
				'purple' => __('Purple','yeahthemes'),
				'red' => __('Red','yeahthemes'),
				'teal' => __('Teal','yeahthemes'),
				'violet' => __('Violet','yeahthemes'),
				'yellow' => __('Yellow','yeahthemes')
			)
		),
		'rel' => array(
			'std' => '',
			'type' => 'select',
			'options' => array(
				'' => __('Select value','yeahthemes'),
				'prettyPhoto' => __('Lightbox','yeahthemes'),
			),
			'label' => __('Rel value', 'yeahthemes'),
			'desc' => __('Eg:  open video/image in lightbox ( support Youtube or Vimeo & image) by entering url to button external url and rel = Lightbox', 'yeahthemes')
		),
		'size' => array(
			'type' => 'select',
			'label' => __('Button Size', 'yeahthemes'),
			'desc' => __('Select the button\'s size', 'yeahthemes'),
			'options' => array(
				'small' => __('Small','yeahthemes'),
				'default' => __('Default','yeahthemes'),
				'medium' => __('Medium','yeahthemes'),
				'large' => __('Large','yeahthemes'),
				'largest' => __('Extra Large','yeahthemes'),
			)
		),
		'type' => array(
			'type' => 'select',
			'label' => __('Button Type', 'yeahthemes'),
			'desc' => __('Select the button\'s type', 'yeahthemes'),
			'options' => array(
				'' => __('default','yeahthemes'),
				'square' => __('Square','yeahthemes'),				
				'rounded' => __('Rounded','yeahthemes')
			)
		),
		'target' => array(
			'type' => 'select',
			'label' => __('Button Target', 'yeahthemes'),
			'desc' => __('_self = open in same window. _blank = open in new window', 'yeahthemes'),
			'options' => array(
				'_self' => '_self',
				'_blank' => '_blank'
			)
		),
		'widefat' => array(
			'type' => 'select2',
			'options' => array( 'true', 'false'),
			'label' => __('Fullwidth button', 'yeahthemes'),
			'std' => '','desc' => '',
		),
		'width' => array(
			'type' => 'text',
			'label' => __('Specified width', 'yeahthemes'),
			'std' => '','desc' => __('Input Numeric number only (eg: 120 - this mean your button\'s width is 150px)', 'yeahthemes'),
		),
		'margin' => array(
			'type' => 'text',
			'label' => __('Margin', 'yeahthemes'),
			'std' => '','desc' => __('Input 4 values : from the left to the right: Margin top - Margin right - Margin bottom - Margin left (eg: 10px 20px 10px 0)', 'yeahthemes'),
		)
	),
	'shortcode' => '[button url="{{url}}" postid="{{postid}}" rel="{{rel}}" style="{{style}}" icon="{{icon}}" iconpos="{{iconpos}}" size="{{size}}" type="{{type}}" target="{{target}}" widefat="{{widefat}}" width="{{width}}" margin="{{margin}}"]{{content}}[/button]',
	'popup_title' => __('Insert Button Shortcode', 'yeahthemes')
);

?>