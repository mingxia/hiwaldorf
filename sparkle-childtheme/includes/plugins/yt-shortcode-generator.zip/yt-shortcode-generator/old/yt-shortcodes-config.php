<?php



/**
 * VARIABLES
 *
 * optionsTrueFalse
 */
$optionsTrueFalse = array(
	'true'=> __('True', 'yeahthemes'),
	'false'=> __('False', 'yeahthemes'),
);
/**
 * optionsShowHide
 */
$optionsShowHide = array(
	'show' => __('Show','yeahthemes'),
	'hide' => __('Hide','yeahthemes')
);
/**
 * optionsAlignment
 */
$optionsAlignment = array(
	'center' => __('Center','yeahthemes'),
	'left' => __('Left','yeahthemes'),
	'right' => __('Right','yeahthemes')
);
/**
 * optionsPosition
 */
$optionsPosition = array(
	'top' => __('Top','yeahthemes'),
	'right' => __('Right','yeahthemes'),
	'bottom' => __('Bottom','yeahthemes'),
	'left' => __('Left','yeahthemes'),
);
/**
 * optionsOrderBy
 */
$optionsOrderBy = array(
	'DESC' => __('Descending','yeahthemes'),
	'ASC' => __('Ascending','yeahthemes')
);

$optionsListIconFont = apply_filters( 'yt_shortcode_vars_iconfont', array());

if(empty($optionsListIconFont)) 
	$optionsListIconFont[''] = __('No icon found.', 'yeahthemes');

/**
 * BEGIN DECLARING SHORTCODE ARRAY
 */
$prefix = apply_filters( 'yt_shortcode_generator_no_conflict', false ) ? 'yt_' : '' ;
/**
 * Button
 */
$yt_shortcodes['button'] = apply_filters( 'yt_shortcode_args_button', array(
			
	'name' => __('Button', 'yeahthemes'),
	'desc' => __('Insert button with various of colors, sizes...', 'yeahthemes'),
	'settings' => array(
		'iconfont' => '',
		'iconimage' => '',
		'syntax' => '[button url="{{url}}" postid="{{postid}}" style="{{style}}" size="{{size}}" target="{{target}}" fullwidth="{{fullwidth}}"]{{text}}[/button]',
	),
	'options' => array(
		'text' => array(
			'name' => __('Button text','yeahthemes'),
			'desc' => '',
			'std' => 'Button',
			'type' => 'text'
		),
		'url' => array(
			'name' => __('External URL','yeahthemes'),
			'desc' => __('Add the button\'s url eg http://example.com','yeahthemes'),
			'std' => '',
			'type' => 'text'
		),
		
		'postid' => array(
			'name' => __('Internal Pages', 'yeahthemes'),
			'desc' => __('You can also link to internal pages. input page id here','yeahthemes'),
			'std' => '',
			'type' => 'text',
		),
		'style' => array(
			'name' => __('Button Style','yeahthemes'),
			'desc' => __('Select the button\'s color style','yeahthemes'),
			'std' => '',
			'type' => 'select',
			'options' => array(
				'btn-default'=> __('Default', 'yeahthemes'),
				'btn-primary' => __('Primary (Theme color)', 'yeahthemes'),
				'btn-success' => __('Success', 'yeahthemes'),
				'btn-info' => __('Info', 'yeahthemes'),
				'btn-warning' => __('Warning', 'yeahthemes'),
				'btn-danger' => __('Danger', 'yeahthemes'),
				'btn-link' => __('Link', 'yeahthemes'),
			)
		),
		'size' => array(
			'name' => __('Button size', 'yeahthemes'),
			'desc' => '',
			'std' => 'default',
			'type' => 'select',
			'options' => array(
				'btn-default' => __('Default', 'yeahthemes'),
				'btn-lg'=> __('Large', 'yeahthemes'),
				'btn-sm' => __('Small', 'yeahthemes'),
				'btn-xs' => __('Extra small', 'yeahthemes'),
			)
		),
		'target' => array(
			'name' => __('Button target', 'yeahthemes'),
			'desc' => __('_self = open in same window. _blank = open in new window', 'yeahthemes'),
			'std' => '_self',
			'type' => 'select',
			'options' => array(
				'_blank'=> '_blank',
				'_parent'=> '_parent',
				'_self'=> '_self',
				'_top'=> '_top',
				'new'=> 'new',
			)
		),
		'fullwidth' => array(
			'name' => __('Fullwidth button', 'yeahthemes'),
			'desc' => '',
			'std' => 'false',
			'type' => 'select',
			'options' => $optionsTrueFalse
		),
		'css' => array(
			'name' => __('Custom CSS','yeahthemes'),
			'desc' => '',
			'std' => '',
			'type' => 'textarea'
		)
		
	)

));	
/**
 * Alerts
 */
$yt_shortcodes['alert'] = apply_filters( 'yt_shortcode_args_alert', array(
			
	'name' => __('Alert box', 'yeahthemes'),
	'desc' => '',
	'settings' => array(
		'iconfont' => '',
		'iconimage' => '',
		'syntax' => '[alert style="{{style}}" close="{{close}}"]{{content}}[/alert]',
	),
	'options' => array(	
		'style' => array(
			'name' => __('Style','yeahthemes'),
			'desc' => __('Select the alert\'s color style','yeahthemes'),
			'std' => '',
			'type' => 'select',
			'options' => array(
				'alert-default'=> __('Default', 'yeahthemes'),
				'alert-success' => __('Success', 'yeahthemes'),
				'alert-info' => __('Info', 'yeahthemes'),
				'alert-warning' => __('Warning', 'yeahthemes'),
				'alert-danger' => __('Danger', 'yeahthemes'),
			)
		),
		'close' => array(
			'name' => __('Close button', 'yeahthemes'),
			'desc' => '',
			'std' => 'false',
			'type' => 'select',
			'options' => $optionsTrueFalse
		),
		'content' => array(
			'name' => __('Content','yeahthemes'),
			'desc' => '',
			'std' => 'This is an alert box!',
			'type' => 'textarea'
		),
	)

));	
/**
 * Label
 */
$yt_shortcodes['label'] = apply_filters( 'yt_shortcode_args_label', array(
			
	'name' => __('Label', 'yeahthemes'),
	'desc' => '',
	'settings' => array(
		'iconfont' => '',
		'iconimage' => '',
		'syntax' => '[label style="{{style}}"]{{text}}[/label]',
	),
	'options' => array(	
		'style' => array(
			'name' => __('Style','yeahthemes'),
			'desc' => __('Select the label\'s color style','yeahthemes'),
			'std' => '',
			'type' => 'select',
			'options' => array(
				'label-default'=> __('Default', 'yeahthemes'),
				'label-primary' => __('Primary', 'yeahthemes'),
				'label-success' => __('Success', 'yeahthemes'),
				'label-info' => __('Info', 'yeahthemes'),
				'label-warning' => __('Warning', 'yeahthemes'),
				'label-danger' => __('Danger', 'yeahthemes'),
			)
		),
		'text' => array(
			'name' => __('Label text','yeahthemes'),
			'desc' => '',
			'std' => 'Label',
			'type' => 'text'
		),
	)

));	

/**
 * Progress bars
 */
$yt_shortcodes['progress_bars'] = apply_filters( 'yt_shortcode_args_progress_bars', array(
			
	'name' => __('Progress bars', 'yeahthemes'),
	'desc' => '',
	'settings' => array(
		'iconfont' => '',
		'iconimage' => '',
		'syntax' => '[progress_bars striped="{{striped}}" active="{{active}}"]{{content}}[/progress_bars]'
	),
	'options' => array(
		
		
		'striped' => array(
			'name' => __('Is striped', 'yeahthemes'),
			'desc' => '',
			'std' => 'false',
			'type' => 'select',
			'options' => $optionsTrueFalse
		),
		'active' => array(
			'name' => __('Is active', 'yeahthemes'),
			'desc' => '',
			'std' => 'false',
			'type' => 'select',
			'options' => $optionsTrueFalse
		),

		'content' => array(
			'name' => __('Allowed multiple bars in a stack ', 'yeahthemes'),
			'desc' => '',
			'std' => '',
			'type' => 'repeatable',
			'settings' => array(
				'iconfont' => '',
				'iconimage' => '',
				'syntax' => '[progress_bar title="{{title}}" width="{{width}}" style="{{style}}"]',
				'add_more' => __('progress bar', 'yeahthemes'),
			
			),
			'options' => array(
			
				'title' => array(
					'std' => 'Text here',
					'type' => 'text',
					'name' => __('Title', 'yeahthemes'),
					'desc' => __('Add the progress bar title', 'yeahthemes')
				),
				'width' => array(
					'std' => '50',
					'type' => 'text',
					'name' => __('Width', 'yeahthemes'),
					'desc' => __('Width of progress bar in percent (input numeric number only)', 'yeahthemes')
				),
				'style' => array(
					'std' => '',
					'type' => 'select',
					'name' => __('Style', 'yeahthemes'),
					'desc' => '',
					'options' => array(
						'progress-bar-primary' => __('Primary', 'yeahthemes'), 
						'progress-bar-success' => __('Success', 'yeahthemes'),
						'progress-bar-info' => __('Info', 'yeahthemes'),
						'progress-bar-warning' => __('Warning', 'yeahthemes'),
						'progress-bar-danger' => __('Danger', 'yeahthemes'),
					)
				)
			)
		),
	)
));
/**
 * Panel
 */
$yt_shortcodes['panel'] = apply_filters( 'yt_shortcode_args_panel', array(
			
	'name' => __('Panel', 'yeahthemes'),
	'desc' => '',
	'settings' => array(
		'iconfont' => '',
		'iconimage' => '',
		'syntax' => '[panel style="{{style}}" title="{{title}}" footer="{{footer}}"]{{content}}[/panel]'
	),
	'options' => array(	
		'style' => array(
			'name' => __('Style','yeahthemes'),
			'desc' => __('Select the Panel\'s color style','yeahthemes'),
			'std' => '',
			'type' => 'select',
			'options' => array(
				'panel-default'=> __('Default', 'yeahthemes'),
				'panel-primary' => __('Primary', 'yeahthemes'),
				'panel-success' => __('Success', 'yeahthemes'),
				'panel-info' => __('Info', 'yeahthemes'),
				'panel-warning' => __('Warning', 'yeahthemes'),
				'panel-danger' => __('Danger', 'yeahthemes'),
			)
		),
		'title' => array(
			'name' => __('Header title','yeahthemes'),
			'desc' => '',
			'std' => 'Panel title',
			'type' => 'text'
		),
		'content' => array(
			'name' => __('Content','yeahthemes'),
			'desc' => '',
			'std' => 'Panel content',
			'type' => 'textarea'
		),
		'footer' => array(
			'name' => __('Footer','yeahthemes'),
			'desc' => '',
			'std' => '',
			'type' => 'text'
		),
	)
));
/**
 * List
 */
$yt_shortcodes['list_group'] = apply_filters( 'yt_shortcode_args_list_group', array(
			
	'name' => __('List group', 'yeahthemes'),
	'desc' => '',
	'settings' => array(
		'iconfont' => '',
		'iconimage' => '',
		'syntax' => '[list_group]{{content}}[/list_group]'
	),
	'options' => array(
		'content' => array(
			'name' => __('Add list items', 'yeahthemes'),
			'desc' => __('if only content is entered, simple style will be used', 'yeahthemes'),
			'std' => '',
			'type' => 'repeatable',
			'settings' => array(
				'iconfont' => '',
				'iconimage' => '',
				'syntax' => '[list_item title="{{title}}" url="{{url}}"]{{content}}[/list_item]',
				'add_more' => __('item', 'yeahthemes'),
			
			),
			'options' => array(
			
				'title' => array(
					'std' => 'This is a list group item',
					'type' => 'text',
					'name' => __('Title (optional)', 'yeahthemes'),
					'desc' => ''
				),
				'url' => array(
					'std' => '',
					'type' => 'text',
					'name' => __('URL', 'yeahthemes'),
					'desc' => __('URL for this item (optional)', 'yeahthemes')
				),
				'content' => array(
					'name' => __('Content','yeahthemes'),
					'desc' => '',
					'std' => 'This is a list group item content',
					'type' => 'textarea'
				)
			)
		),
	)
));
/**
 * Column
 */
$yt_shortcodes['column'] = apply_filters( 'yt_shortcode_args_column', array(
			
	'name' => __('Column', 'yeahthemes'),
	'desc' => '',
	'settings' => array(
		'iconfont' => '',
		'iconimage' => '',
		'syntax' => '[row]{{content}}[/row]'
	),
	'options' => array(
		'content' => array(
			'name' => __('Add column', 'yeahthemes'),
			'desc' => __('if no column class was specified, use default column: col-md-4', 'yeahthemes'),
			'std' => '',
			'type' => 'repeatable',
			'settings' => array(
				'iconfont' => '',
				'iconimage' => '',
				'syntax' => '[column class="{{xs}}{{sm}}{{md}}{{lg}}"]{{content}}[/column]',
				'add_more' => __('column', 'yeahthemes'),
			
			),
			'options' => array(
			
				'xs' => array(
					'std' => '',
					'type' => 'select_alt',
					'name' => __('Extra small (<768px)', 'yeahthemes'),
					'desc' => '',
					'options' => array(
						'',
						' col-xs-1',
						' col-xs-2',
						' col-xs-3',
						' col-xs-4',
						' col-xs-5',
						' col-xs-6',
						' col-xs-7',
						' col-xs-8',
						' col-xs-9',
						' col-xs-10',
						' col-xs-11',
						' col-xs-12',
					)
				),
				'sm' => array(
					'std' => '',
					'type' => 'select_alt',
					'name' => __('Small (≥768px)', 'yeahthemes'),
					'desc' => '',
					'options' => array(
						'',
						' col-sm-1',
						' col-sm-2',
						' col-sm-3',
						' col-sm-4',
						' col-sm-5',
						' col-sm-6',
						' col-sm-7',
						' col-sm-8',
						' col-sm-9',
						' col-sm-10',
						' col-sm-11',
						' col-sm-12',
					)
				),
				'md' => array(
					'std' => '',
					'type' => 'select_alt',
					'name' => __('Medium (≥992px)', 'yeahthemes'),
					'desc' => '',
					'options' => array(
						'',
						' col-md-1',
						' col-md-2',
						' col-md-3',
						' col-md-4',
						' col-md-5',
						' col-md-6',
						' col-md-7',
						' col-md-8',
						' col-md-9',
						' col-md-10',
						' col-md-11',
						' col-md-12',
					)
				),
				'lg' => array(
					'std' => '',
					'type' => 'select_alt',
					'name' => __('Large (≥1200px)', 'yeahthemes'),
					'desc' => '',
					'options' => array(
						'',
						' col-lg-1',
						' col-lg-2',
						' col-lg-3',
						' col-lg-4',
						' col-lg-5',
						' col-lg-6',
						' col-lg-7',
						' col-lg-8',
						' col-lg-9',
						' col-lg-10',
						' col-lg-11',
						' col-lg-12',
					)
				),
				'content' => array(
					'name' => __('Content','yeahthemes'),
					'desc' => '',
					'std' => 'Grumpy wizards make toxic brew for the evil Queen and Jack. 1234567890',
					'type' => 'textarea'
				)
			)
		),
	)
));

/**
 * Tabs
 */
$yt_shortcodes['tabs'] = apply_filters( 'yt_shortcode_args_tabs', array(
			
	'name' => __('Tabs', 'yeahthemes'),
	'desc' => '',
	'settings' => array(
		'iconfont' => '',
		'iconimage' => '',
		'syntax' => '[tabs style="{{style}}"]{{content}}[/tabs]'
	),
	'options' => array(
		'style' => array(
			'type' => 'select',
			'name' => __('Style', 'yeahthemes'),
			'options' => array(
				'default' => __('Default', 'yeahthemes'),
				'pills' => __('Pills', 'yeahthemes'),
			)
		),
		'content' => array(
			'name' => __('Add tab', 'yeahthemes'),
			'desc' => '',
			'std' => '',
			'type' => 'repeatable',
			'settings' => array(
				'iconfont' => '',
				'iconimage' => '',
				'syntax' => '[tab title="{{title}}"]{{content}}[/tab]',
				'add_more' => __('tab', 'yeahthemes'),
			
			),
			'options' => array(
				'title' => array(
					'name' => __('Tab title','yeahthemes'),
					'desc' => __('Title must be different to different to others','yeahthemes'),
					'std' => '',
					'type' => 'text'
				),
				'content' => array(
					'name' => __('Tab Content','yeahthemes'),
					'desc' => '',
					'std' => 'Grumpy wizards make toxic brew for the evil Queen and Jack. 1234567890',
					'type' => 'textarea'
				)
			)
		),
	)
));

/**
 * Accordion
 */
$yt_shortcodes['accordion'] = apply_filters( 'yt_shortcode_args_accordion', array(
			
	'name' => __('Accordion', 'yeahthemes'),
	'desc' => '',
	'settings' => array(
		'iconfont' => '',
		'iconimage' => '',
		'syntax' => '[accordion style="{{style}}"]{{content}}[/accordion]'
	),
	'options' => array(
		'style' => array(
			'type' => 'select',
			'name' => __('Style', 'yeahthemes'),
			'options' => array(
				'default' => __('Default', 'yeahthemes'),
				'primary' => __('Primary color', 'yeahthemes'),
				'success' => __('Success', 'yeahthemes'),
				'info' => __('Info', 'yeahthemes'),
				'warning' => __('Warning', 'yeahthemes'),
				'danger' => __('Danger', 'yeahthemes'),
			)
		),
		'content' => array(
			'name' => __('Add accordion', 'yeahthemes'),
			'desc' => '',
			'std' => '',
			'type' => 'repeatable',
			'settings' => array(
				'iconfont' => '',
				'iconimage' => '',
				'syntax' => '[accordion_item title="{{title}}"]{{content}}[/accordion_item]',
				'add_more' => __('accordion', 'yeahthemes'),
			
			),
			'options' => array(
				'title' => array(
					'name' => __('Title','yeahthemes'),
					'desc' => __('Title must be different to different to others','yeahthemes'),
					'std' => '',
					'type' => 'text'
				),
				'content' => array(
					'name' => __('Content','yeahthemes'),
					'desc' => '',
					'std' => 'Grumpy wizards make toxic brew for the evil Queen and Jack. 1234567890',
					'type' => 'textarea'
				)
			)
		),
	)
));

$yt_shortcodes['shortcode_item_separator'] = '';
/**
 * Google Maps 
 */
$yt_shortcodes['gmap'] = apply_filters( 'yt_shortcode_args_gmap', array(
	
	'name' => __('Google Maps', 'yeahthemes'),
	'desc' => __('Google Maps', 'yeahthemes'),
	'settings' => array(
		'iconfont' => '',
		'iconimage' => '',
		'syntax' => '[gmap address="{{address}}" maptype="{{maptype}}" height="{{height}}" latitude="{{latitude}}" longitude="{{longitude}}" zoom="{{zoom}}" hue="{{hue}}" saturation="{{saturation}}" roadgeometry_lightness="{{roadgeometry_lightness}}" roadgeometry_visibility="{{roadgeometry_visibility}}" roadlabels_visibility="{{roadlabels_visibility}}" controls="{{control}}" marker="{{marker}}" marker_title="{{marker_title}}" imageurl="{{imageurl}}" imageid="{{imageid}}" markerw="{{markerw}}" markerh="{{markerh}}" anchorh="{{anchorh}}" anchorv="{{anchorv}}" popup="{{popup}}"]{{html}}[/gmap]'
	),
	'options' => array(
		'address' => array(
			'name' => __('Address', 'yeahthemes'),
			'desc' => __('Enter your address (e.g: Melbourne Avenue, Birmingham, United Kingdom) ', 'yeahthemes'),
			'type' => 'text',
		),
		'latitude' => array(
			'name' => __('Latitude', 'yeahthemes'),
			'desc' => __('Enter Latitude <a href="http://9webtools.com/find-my-latitude-and-longitude/" target="_blank">Find your latitude,longitude</a>', 'yeahthemes'),
			'type' => 'text',
			'std' => '0',
		),
		'longitude' => array(
			'name' => __('Longitude', 'yeahthemes'),
			'desc' => __('Enter Longitude', 'yeahthemes'),
			'type' => 'text',
			'std' => '0',
		),
		'maptype' => array(
			'name' => __('Select the Maptype', 'yeahthemes'),
			'desc' => __('HYBRID, TERRAIN, SATELLITE, ROADMAP', 'yeahthemes'),
			'type' => 'select',
			'options' => array(
				'ROADMAP' => __('Road Map','yeahthemes'),
				'TERRAIN' => __('Terrain','yeahthemes'),
				'HYBRID' => __('Hybrid','yeahthemes'),
				'SATELLITE' => __('Satellite','yeahthemes')
			)
		),
		'height' => array(
			'name' => __('Height', 'yeahthemes'),
			'desc' => __('default is 300) ', 'yeahthemes'),
			'type' => 'text',
		),
		'html' => array(
			'name' => __('HTML', 'yeahthemes'),
			'desc' => __('Short description in the Marker popup (e.g: My Hometown) ', 'yeahthemes'),
			'type' => 'textarea',
			'std' => __('My Hometown','yeahthemes'),
		),
		'zoom' => array(
			'type' => 'select_alt',
			'std' => '15',
			'options' => array('1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22'),
			'name' => __('Zoom level', 'yeahthemes'),
			'desc' => __('Zoom	(default : 15)) ', 'yeahthemes'),
		),
		'hue' => array(
			'type' => 'colorpicker',
			'std' => '',
			'name' => __('Map Hue', 'yeahthemes'),
			'desc' => __('Style your map by changing the hue color to any color (hex color start with #) Eg: Your main color of your site : #33B3D3', 'yeahthemes'),
		),
		'saturation' => array(
			'name' => __('Map saturation', 'yeahthemes'),
			'desc' => __('Alter the saturation of your map. Range (grayscale) -100 - 0 - 100 (color)', 'yeahthemes'),
			'type' => 'text',
			'std' => '0',
		),
		'roadgeometry_lightness' => array(
			'name' => __('Road geometry lightness', 'yeahthemes'),
			'desc' => __('Alter the saturation of your map. Range (dark) -100 - 0 - 100 (light)', 'yeahthemes'),
			'type' => 'text',
			'std' => '0',
		),
		'roadgeometry_visibility' => array(
			'type' => 'select',
			'options' => array(
				'on',
				'simplified',
				'off'
			),
			'std' => 'on',
			'name' => __('Road geometry visibility', 'yeahthemes'),
			'desc' => ''
		),
		'roadlabels_visibility' => array(
			'name' => __('Road labels visibility', 'yeahthemes'),
			'desc' => '',
			'type' => 'select',
			'options' => array(
				'on',
				'simplified',
				'off'
			),
			'std' => 'on',
		),
		
		/*'style' => array(
			'type' => 'textarea',
			'std' => '0',
			'name' => __('Map Style', 'yeahthemes'),
			'desc' => __('Customize your map style (colors of road, water, transit, ...ect) at <a href="http://gmaps-samples-v3.googlecode.com/svn/trunk/styledmaps/wizard/index.html" target="_blank"> and paste the generated JSON data here', 'yeahthemes')
		),*/
		'control' => array(
			'type' => 'select',
			'name' => __('Show Control', 'yeahthemes'),
			'options' => $optionsTrueFalse
		),
		'marker' => array(
			'type' => 'select',
			'name' => __('Show Marker', 'yeahthemes'),
			'options' => $optionsTrueFalse
		),
		'marker_title' => array(
			'name' => __('Marker title', 'yeahthemes'),
			'desc' => '',
			'type' => 'text',
		),
		'imageid' => array(
			'name' => __('Internal Image', 'yeahthemes'),
			'desc' => __('Upload Map pointer ', 'yeahthemes'),
			'type' => 'media',
			'settings' => array(
				'media_by' => 'id'
			)
		),
		'imageurl' => array(
			'name' => __('External Image url', 'yeahthemes'),
			'desc' => __('Map pointer url that you want to display on map', 'yeahthemes'),
			'type' => 'text',
		),
		'markerw' => array(
			'name' => __('Marker width', 'yeahthemes'),
			'desc' => __('Width of marker in px', 'yeahthemes'),
			'type' => 'text',
			'std' => '',
		),
		'markerh' => array(
			'name' => __('Marker height', 'yeahthemes'),
			'desc' => __('Height of marker in px', 'yeahthemes'),
			'type' => 'text',
			'std' => '',
		),
		'anchorh' => array(
			'name' => __('Marker Anchor Horizontal position', 'yeahthemes'),
			'desc' => '',
			'type' => 'text',
			'std' => '',
		),
		'anchorv' => array(
			'name' => __('Marker Anchor Vertical position', 'yeahthemes'),
			'desc' => '',
			'type' => 'text',
			'std' => '',
		),
		'popup' => array(
			'name' => __('Show Popup', 'yeahthemes'),
			'type' => 'select',
			'std'	=> 'false',
			'options' => $optionsTrueFalse,
		)
	)
) );


$yt_shortcodes['shortcode_item_separator'] = '';